### Packages ###
import tkinter as tk
from tkinter import scrolledtext, ttk
from tkinter import filedialog
import customtkinter as ctk
from style import Colors, Styles
import pandas as pd
# from tkPDFViewer import tkPDFViewer
import tkPDFViewer
from editable_table import EditableTable
from Final_Model_File_local import predict
import jsontodf as jdf
import os
from pdftojson import pdf_to_images,process_images,save_results_to_json,clear_output_folder


#Singleton class
class ExtractTabEditableTableSingleton():

    frameCreated = False

    @classmethod
    def createFrame(cls,parentFrame,data):
        if(cls.frameCreated == False):
            EditableTable(parentFrame,data) 
            cls.frameCreated = True            

#Singleton class
class PredictionTabEditableTableSingleton():

    frameCreated = False

    @classmethod
    def createFrame(cls,parentFrame,data):
        if(cls.frameCreated == False):
            EditableTable(parentFrame,data) 
            cls.frameCreated = True     

class OnPremise:
    
    
    def __init__(self,app):
        self.app = app
        self.mainFrame = None
        self.pdfFrame = None
        self.displatFrame = None
        self.createFrame()
        self.predictionFrame = None
        self.file_path = None
        
    def createFrame(self):
       
         # Tabs
        notebook_style = ttk.Style()
        # notebook_style.theme_create("CustomStyle", parent="alt", settings={
        #     "TNotebook": {"configure": {"background": Colors.primaryBlue}},
        #     "TNotebook.Tab": {"configure": {"padding": [10, 10], "font": ('Arial', 12),
        #                                     "borderwidth": 0, "highlightthickness": 0, "focuscolor": Colors.white},
        #                     "map": {"background": [("selected", Colors.white), ("!selected", Colors.primaryBlue)],
        #                             "foreground": [("selected", Colors.primaryBlue), ("!selected", Colors.white)]}}
        # })
        #notebook_style.theme_use("CustomStyle")


        # notebook_style.configure("TNotebook", background = Colors.white)

        notebook_style.configure(style="TNotebook.Tab",  padding=[10, 10], background = Colors.primaryBlue, foreground = Colors.black,
                         font=('Arial', 15), borderwidth = 0, highlightthickness=0, focuscolor = Colors.white)

        notebook_style.map(style="TNotebook.Tab", foreground=[("selected", Colors.primaryBlue), ("!selected", Colors.black) ])

        # Create the Notebook
        notebook = ttk.Notebook(self.mainFrame)
        notebook.pack(padx=20, pady=10, fill='both', expand=True)
        transcriptExtractTab = tk.Frame(notebook, bg = Colors.white)
        predictionTab = tk.Frame(notebook, bg = Colors.white)

        self.transcriptExtraction(transcriptExtractTab)
        self.predictions(predictionTab)

        notebook.add(transcriptExtractTab, text='Transcript Data Extraction')
        notebook.add(predictionTab, text='Predictions')

        self.mainFrame = notebook

    def transcriptExtraction(self,tab):
        paned_window = tk.PanedWindow(tab, orient=tk.HORIZONTAL, borderwidth = 0, sashwidth = 0)
        paned_window.pack(fill=tk.BOTH, expand=True)

        uploadFrame = tk.Frame(tab, bg = Colors.silver, highlightthickness = 0, padx = 20)
        displatFrame = tk.Frame(tab, bg = Colors.white, highlightthickness = 0, padx = 5, pady = 5)
        # uploadFrame.pack(side = "left", fill = "both", expand = True)
        displatFrame.pack(anchor="w")
        paned_window.add(uploadFrame)
        paned_window.add(displatFrame)
        
        self.uploadFrame(uploadFrame)
        self.displatFrame = displatFrame
        # left_pane = PDFViewer(paned_window, pdf_path=file_path)
        #paned_window.add(left_pane, weight=1)

    def predictions(self,tab):
        predictionFrame = tk.Frame(tab, bg = "white", highlightthickness = 0)
        predictionFrame.pack(anchor="w", fill=tk.BOTH, expand=True)

        frame = tk.Frame(predictionFrame, bg ="white", highlightthickness = 0)
        frame.pack(anchor="w")

        label = tk.Label(frame, text="Select the program", bg="white", fg = Colors.primaryBlue)
        label.pack(side="left", anchor="w", padx=10, pady=10)

        combobox_style = {
            'fg_color': Colors.primaryBlue
        }

        combobox = ctk.CTkComboBox(master=frame, state="readonly", hover = False, values=["Programs","EOM", "Data Science"], **combobox_style)
        combobox.set("Programs")
        combobox.pack(side='left', padx=10, pady=10)

        button = ctk.CTkButton(master=frame, text="Upload", command = lambda:self.displayPredictionExcel(predictionFrame), **Styles.buttonStyle)
        button.pack(anchor="w", padx=10, pady=10)

        self.predictionFrame = predictionFrame

    def uploadFrame(self,uploadFrame):
        frame = tk.Frame(uploadFrame, bg = Colors.silver, highlightthickness = 0)
        frame.pack(anchor="w")
        label = tk.Label(frame, text="Upload a transcript file to extract the data", bg = Colors.silver, fg = Colors.primaryBlue)
        label.pack(side="left", padx=10, pady=10)
        # button = tk.Label(frame, text="Upload File", **Styles.buttonStyle)
        # button.pack(side="left")
        # button.bind("<Button-1>", self.uploadFiles)
        button = ctk.CTkButton(master = frame, text="Upload File", command=self.uploadFiles, **Styles.buttonStyle)
        button.pack(side="left", padx=10, pady=10)

        self.pdfFrame = tk.Frame(uploadFrame, bg = Colors.white, width = 550)
        self.pdfFrame.pack(anchor="w", fill = "y", expand = True)

        # proceed = tk.Label(uploadFrame, text="Procced to extract data", **Styles.buttonStyle)
        # proceed.pack(side="left")
        # proceed.bind("<Button-1>", self.extractData)

        proceed = ctk.CTkButton(master = uploadFrame, text="Procced to extract data", command = self.extractData,width=200, **Styles.buttonStyle)
        proceed.pack(side="left", padx=10, pady=10)

    '''def uploadFiles(self, event=None):
        file = filedialog.askopenfilename(filetypes=[("PDF Files", "*.pdf"),("Excel File","*.xlsx")])
        if file.endswith(".pdf"):
            pdf = tkPDFViewer.ShowPdf()
            pdf.img_object_li.clear()
            with open(file, "rb") as f:
                pdfDisplay = pdf.pdf_view(self.pdfFrame, pdf_location = f)
                pdfDisplay.pack(fill=tk.BOTH, expand=True)
                self.pdfFrame.pack_propagate(False)
        else:
            label = tk.Label(self.pdfFrame, text = "Other file formats are not supported yet")
            self.filepath= file
            #label.pack()
            #window.after(5000, lambda: label.pack_forget())

    def extractData(self, event=None):
    
    ########## USE OCR ###########

    # -------- Temp ------------ #
        df = pd.read_excel(r"BPnPpemQ.xlsx")
        self.displayExcel(df) '''
        
    def uploadFiles(self, event=None):
        file = filedialog.askopenfilename(filetypes=[("PDF Files", "*.pdf"),("Excel File","*.xlsx")])
        self.file_path = file
        if file.endswith(".pdf"):
            output_folder = r"C:\Users\chara\Downloads\Modified Ui\Image_Folder"
        
            # Clear the output folder before saving new images
            clear_output_folder(output_folder)
        
        # Convert PDF to images
            pdf_to_images(file, output_folder)
        
        # Display PDF
            pdf = tkPDFViewer.ShowPdf()
            pdf.img_object_li.clear()
            with open(file, "rb") as f:
                pdfDisplay = pdf.pdf_view(self.pdfFrame, pdf_location = f)
                pdfDisplay.pack(fill=tk.BOTH, expand=True)
                self.pdfFrame.pack_propagate(False)
        else:
            self.extractData()

    def extractData(self, event=None):
        if self.file_path is not None:
            if self.file_path.endswith(".pdf"):
                df = jdf.process_json_file(r"C:/Users/chara/Downloads/ADM-UI/full_formatted_results_with_marks.json")
                print(df)
                fileName = 'excel_files/' + os.path.splitext(os.path.basename(self.file_path))[0] + '.xlsx'
                df.to_excel(fileName, index=False)
                self.file_path = fileName
            else:
                df = pd.read_excel(self.file_path)
            self.displayExcel(df)
        else:
            print("No file selected")    
    
    def displayExcel(self, df):

        ExtractTabEditableTableSingleton.createFrame(self.displatFrame,df)
        predictButton = ctk.CTkButton(master = self.displatFrame, text="Predict", command = lambda:self.finalPredict(self.displatFrame), **Styles.buttonStyle) 
        predictButton.pack(side="left", padx = 10, pady = 10)

    def displayPredictionExcel(self, tab):
        # Add the engine parameter to specify the Excel format
        df = pd.read_excel(self.file_path, engine='openpyxl')
        PredictionTabEditableTableSingleton.createFrame(tab,df) 
        predictButton = ctk.CTkButton(master = tab, text="Predict", command = lambda:self.finalPredict(tab), **Styles.buttonStyle) 
        predictButton.pack(side="left", padx = 10, pady = 10)

    def finalPredict(self, frame):
    
        predictedResult,math_average,number_of_math_courses,programming_average,number_of_programming_courses,number_of_fails,Course_Weighted_Average = predict(self.file_path)
        predicted_label = tk.Label(frame, text=f"Predicted GPA: {predictedResult}", font=("Times New Roman", 15), bg = Colors.white, fg = Colors.green)
        predicted_label.pack(side="left", padx = 10, pady = 10)
        math_information_label = tk.Label(frame, text=f"Number of Math courses:{number_of_math_courses} \n Math Average score: {math_average}", font=("Times New Roman", 15), bg = Colors.white, fg = Colors.blue)
        math_information_label.pack(side="left", padx = 10, pady = 10)
        math_information_label = tk.Label(frame, text=f"Programming Average score: {programming_average} \n Number of Programming courses:{number_of_programming_courses}", font=("Times New Roman", 15), bg = Colors.white, fg = Colors.blue)
        math_information_label.pack(side="left", padx = 10, pady = 10)
        number_of_fails_label = tk.Label(frame, text=f"Number of Fails: {number_of_fails}", font=("Times New Roman", 15), bg = Colors.white, fg = Colors.blue)
        number_of_fails_label.pack(side="left", padx = 10, pady = 10)
        Course_Weighted_Average_label = tk.Label(frame, text=f"CGPA: {Course_Weighted_Average}", font=("Times New Roman", 15), bg = Colors.white, fg = Colors.blue)
        Course_Weighted_Average_label.pack(side="left", padx = 10, pady = 10)