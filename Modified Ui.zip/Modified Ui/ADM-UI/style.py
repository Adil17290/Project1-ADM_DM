
#### COLORS ####
class Colors:
    primaryBlue = "#003e65" #"#007bff" #"#003e65"
    white = "white"
    silver = "silver"
    blue = 'blue'
    lightGray = "#D3D3D3"
    black = 'black'
    green = "green"

### STYLE ####

class Styles:
    buttonStyle = {
        'border_width': 0,
        'corner_radius': 5,
        'fg_color': Colors.primaryBlue
    }