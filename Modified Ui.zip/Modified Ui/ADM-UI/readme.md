## Setup

1. python -m venv adm

2. On Windows: myenv\Scripts\activate

3. On macOS and Linux: source myenv/bin/activate

4. Install packages: pip install -r requirements.txt

## To run the application

1. python app.py