# import tkinter as tk
# from tkinter import scrolledtext, ttk
# from PIL import Image, ImageTk
# from ttkthemes import ThemedStyle
# import customtkinter as ctk
# from on_premise import OnPremise
# import dashboard
# from pdf2image import convert_from_path
# import os
# from style import Styles
'''
from paddleocr import PaddleOCR

from PIL import Image, ImageDraw

import numpy as np
import pandas as pd

import time

import math
from typing import Tuple, Union
from statistics import mode, mean

import re
from fuzzywuzzy import fuzz

from utils import TranscriptOCR

import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

'''

### Packages ###
import tkinter as tk
from tkinter import scrolledtext, ttk
from PIL import Image, ImageTk
from ttkthemes import ThemedStyle
from style import Colors, Styles
from on_premise import OnPremise, ExtractTabEditableTableSingleton, PredictionTabEditableTableSingleton
import customtkinter as ctk
from pdftojson import *

premise = None

def show_about():
    show_content("ABOUT PROJECT")


def show_how_to_use():
    show_content("HOW TO USE")


def show_team():
    show_content("TEAM")

def home():
    global premise
    if(premise == None):
        return
    premise.mainFrame.destroy()
    PredictionTabEditableTableSingleton.frameCreated = False
    ExtractTabEditableTableSingleton.frameCreated = False
    premise = None

def show_content(content_text):
    content_window = tk.Toplevel(app)
    content_window.title(content_text)
    content_window.geometry(f"{screen_width}x{screen_height}")
    content_label = tk.Label(content_window, text=f"This is the {content_text} page.", font=("Arial", 16))
    content_label.pack(padx=20, pady=20)
    back_button = ttk.Button(content_window, text="Back", style="TButton", cursor="hand2", command=content_window.destroy)
    back_button.pack(side="bottom", padx=20, pady=10)

# def mode_select(mode):
#     menuButton.config(text = mode)
#     if(mode == "Remote"):
#         pass
#     else:
#         premise = OnPremise(app)

def selectMode(mode):
    global premise
    if(mode.get() == "Remote"):
        pass
    elif(mode.get() == "On Premise"):
        premise = OnPremise(app)

app = tk.Tk()
app.title("Admissions Portal")

### Adding Theme ###
style = ThemedStyle(app)
style.set_theme("arc")

screen_width = app.winfo_screenwidth()
screen_height = app.winfo_screenheight()

app.geometry(f"{screen_width}x{screen_height}")

bg_image = Image.open("images/university-new-haven_hero.jpeg")
bg_image = bg_image.resize((screen_width, screen_height))
bg_photo = ImageTk.PhotoImage(bg_image)
background_label = tk.Label(app, image=bg_photo)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
background_label.lower() 

### Nav Bar #####
frame = tk.Frame(app, bg="white", padx = 20, pady=0)
frame.pack(side="top", fill="x")
logo_image = Image.open("images/unh-logo.png")
logo_image = logo_image.resize((50, 50))
logo_image = ImageTk.PhotoImage(logo_image)
logo_label = tk.Label(frame, image=logo_image, bg = "white", width = 50, height = 50)
logo_label.pack(side="left")
label = tk.Label(frame, text="University of New Haven Admissions Portal", bg="white", fg="#003e65", font=("Algerian", 18))
label.pack(side="left", fill="x")

#### Mode ####
# frame = tk.Frame(frame, padx=20, pady=10, width = 100, bg = "white")
# frame.pack(side="right", anchor="ne")
# label = tk.Label(frame, text="Mode", font=("Arial", 15, "bold"), bg = "white", fg = "black")
# label.pack(side="top", anchor="w", padx=20, pady=10)

# menuButton = tk.Menubutton (frame, width=7, text="Mode", bg = "white", fg = "black")
# menuButton.menu = tk.Menu (menuButton, tearoff = 0)
# menuButton["menu"] =  menuButton.menu
# menuButton.menu.add_command(label="On Premise", command=lambda:mode_select("On Premise"))
# menuButton.menu.add_command(label="Remote", command=lambda:mode_select("Remote"))
# #mode_select("On Premise")
# menuButton.pack(side="top", anchor="w", padx=20, pady=0)

# Dashboard(app)

#### Nav Bar ####
nav_frame = tk.Frame(app, bg="#003e65", padx=20, pady=0, bd=1, relief="raised")
nav_frame.pack(side="left", fill="y")

nav_title = tk.Label(nav_frame, text="ADM-MENU", bg="#003e65", fg="white", font=("Arial", 20, "bold"))
nav_title.pack(pady=20)

nav_items = [
    ("Home", home),
    ("About project", show_about),
    ("How to use", show_how_to_use),
    ("Team", show_team),
    ("Add student profiles", None),
    ("Train model", None),
    ("Settings", None),
] 

for item_text, command in nav_items:
    item_button = ttk.Button(nav_frame, text=item_text, style="TButton", cursor="hand2", command=command)
    item_button.pack(fill="x", padx=10, pady=5)

kpi_frame = tk.Frame(app, bg = Colors.white, bd = 0, relief="raised", padx = 10, pady = 10)
kpi_frame.place(relx = 0.90, rely=0.1, anchor="ne")

def create_kpi(parent, text, value):
    box = ctk.CTkFrame(parent, bg_color = Colors.white, fg_color = Colors.primaryBlue, corner_radius = 10)
    box.pack(side="left", padx = 10, pady = 10)
    frame = tk.Frame(box, bg = Colors.lightGray)
    frame.pack(side="left", padx = 10, pady = 10)
    title_label = tk.Label(frame, text = text, font=("Arial", 18, "bold"), fg = "white", padx = 10, pady = 10, bg = Colors.primaryBlue)
    title_label.pack()
    # value_frame = tk.Frame(frame)
    # value_frame.pack(side="bottom", fill="x", padx=5, pady=2)
    value_label = tk.Label(frame, text=value, font=("Arial", 16), fg = "black", padx=5, pady = 2, bg = Colors.lightGray)
    value_label.pack()

kpi1_text = "Total applicants"
kpi1_value = "220"
create_kpi(kpi_frame, kpi1_text, kpi1_value)

kpi2_text = "Total Number of Transcripts"
kpi2_value = "220"
create_kpi(kpi_frame, kpi2_text, kpi2_value)

kpi3_text = "Predicted Average GPA"
kpi3_value = "3.42"
create_kpi(kpi_frame, kpi3_text, kpi3_value)

kpi4_text = "Model Accuracy"
kpi4_value = "70%"
create_kpi(kpi_frame, kpi4_text, kpi4_value)

# Add radio button on image
radio_var = tk.StringVar()
radio_frame = tk.Frame(background_label, bg="#ffffff", borderwidth = 0.5, relief="solid")
radio_frame.place(relx=0.55, rely=0.40, anchor="center")

radio_label = tk.Label(radio_frame, text="Mode of Operation", font=("Arial", 16), bg="#ffffff", fg="black")
radio_label.grid(row=0, column=0, padx=10, pady=10)

radio_option1 = tk.Radiobutton(radio_frame, text="On Premise", variable=radio_var, value="On Premise", font=("Arial", 14), bg="#ffffff", fg="black", activebackground="#ffffff", activeforeground="black")
radio_option1.grid(row=0, column=1, padx=10, pady=10)

radio_option2 = tk.Radiobutton(radio_frame, text="Remote", variable=radio_var, value="Remote", font=("Arial", 14), bg="#ffffff", fg="black", activebackground="#ffffff", activeforeground="black")
radio_option2.grid(row=0, column=2, padx=10, pady=10)

# style = ttk.Style()
# style.configure(style = "Custom.TButton", padding=15, relief="flat", background="#023e8a", foreground="#023e8a", bordercolor="#023e8a", borderwidth=0, font=("Arial", 16))

# proceed_button = tk.Button(app, text="Proceed", cursor="hand2", relief="raised", bg = Colors.primaryBlue, fg = Colors.black, width=20, command = lambda:selectMode(radio_var))
# proceed_button.place(relx=0.55, rely=0.57, anchor="center")

button = ctk.CTkButton(master = app, text="Proceed", width = 200, height = 50, command = lambda:selectMode(radio_var), **Styles.buttonStyle)
button.place(relx=0.55, rely = 0.50, anchor="center")

app.mainloop()

# nav_items = [
#     ("Home", home),
#     ("ABOUT PROJECT", show_about),
#     ("HOW TO USE", show_how_to_use),
#     ("TEAM", show_team),
#     ("Add student profiles", None),
#     ("Train model", None),
#     ("About", None),
#     ("Settings", None),
# ] 
