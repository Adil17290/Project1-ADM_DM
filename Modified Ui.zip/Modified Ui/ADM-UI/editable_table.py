### Packages ###
import tkinter as tk
from tkinter import scrolledtext, ttk
import pandas as pd
from style import Colors, Styles
import customtkinter as ctk
from tkinter import simpledialog

class EditableTable():

    def __init__(self,parentFrame,data):
        columns = data.columns
        self.parentFrame = parentFrame

        # self.excelSaveButton = tk.Label(parentFrame, text="Save", **Styles.buttonStyle)
        # self.excelSaveButton.bind("<Button-1>", self.saveExcel)
        self.excelSaveButton = ctk.CTkButton(master = parentFrame, text="Save", command = self.saveExcel, **Styles.buttonStyle)

        treeScroll = ttk.Scrollbar(parentFrame)
        treeScroll.pack(side="right", fill = "y")

        self.tree = ttk.Treeview(parentFrame, columns=list(columns), show="headings", yscrollcommand = treeScroll.set)

        style = ttk.Style()
        style.configure("Treeview.Heading", font=("Arial", 14, "bold"))
        style.configure("Treeview", font=("Arial", 10))
        style.configure("Treeview", background = Colors.white, bordercolor="light gray")
        style.map("Treeview", background=[('selected', Colors.primaryBlue)], foreground = [("selected", Colors.white)])
        style.configure("Treeview.Heading", background = Colors.lightGray)
        
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor=tk.CENTER)

        for index, row in data.iterrows():
            self.tree.insert("", tk.END, values=list(row))

        self.tree.bind("<Double-1>", self.editExcel)

        self.tree.pack(fill=tk.BOTH, expand=True)
    
    def editExcel(self, event):
        region = self.tree.identify_region(event.x, event.y)

        if "cell" in region:
            item = self.tree.selection()[0]
            col = self.tree.identify_column(event.x).split("#")[-1]
            col = int(col)-1
            old_value = self.tree.item(item, "values")[col]
            new_value = simpledialog.askstring("Edit Cell", f"Edit cell value:", initialvalue = old_value)

            if new_value is not None:
                self.tree.set(item, col, new_value)
                self.excelSaveButton.pack(side="bottom", anchor="sw", padx=10, pady=10)

    def saveExcel(self):
        
        columns = self.tree["columns"]
        columnNames = [self.tree.heading(col)["text"] for col in columns]
        data = []
        for item in self.tree.get_children(''):
            values = [self.tree.item(item, "values")[col] for col in range(len(columnNames))]
            data.append(values)

        data = pd.DataFrame(data, columns = columns)
        print(data)
        self.excelSaveButton.pack_forget()