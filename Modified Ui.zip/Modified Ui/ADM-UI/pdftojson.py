from pdf2image import convert_from_path
import cv2
import layoutparser as lp
import json
import glob
from utils import TranscriptOCR
import os
import shutil
# Initialize the TranscriptOCR object
transcriptocr = TranscriptOCR()

def clear_output_folder(output_folder):
    # Delete all files in the output folder
    for filename in os.listdir(output_folder):
        file_path = os.path.join(output_folder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print(f'Failed to delete {file_path}. Reason: {e}')

def pdf_to_images(pdf_path, output_folder):
    pdf_path = "C:/Users/chara/Downloads/ADM-UI/_0yr2Fyo_Transcript.pdf"
    print("\n Loading PDF: {}\n".format(pdf_path))
    images = convert_from_path(pdf_path)

    print("\n Converting PDF to images \n")
    for i, image in enumerate(images):
        image_path = "{}/page{}.jpg".format(output_folder, i)
        image.save(image_path, 'JPEG')
        print("Image saved: {}".format(image_path))

def process_images(image_folder):
    # Get a list of all image files in the directory
    image_files = glob.glob(f"{image_folder}/*.jpg") + glob.glob(f"{image_folder}/*.png")
    
    # Initialize an empty list to store the results
    results = []

    # Loop through each image file and process it
    for image_file in image_files:
        try:
            result = transcriptocr.extract_json(image_file)
            results.append(result)
        except Exception as e:
            print(f"Failed to process {image_file}: {e}")

    return results

def save_results_to_json(results, output_path):
    # Combine all the results into a single JSON object
    combined_result = {"results": results}
    combined_json = json.dumps(combined_result, indent=4)

    # Write the combined JSON object to a file
    with open(output_path, "w") as f:
        f.write(combined_json)
'''
if __name__ == "__main__":
    pdf_path = 'fIQccmOI_Transcript-test.pdf'
    output_folder = 'Output_Folder'
    output_json_path = 'combined_results.json'
    
    # Convert PDF to images
    pdf_to_images(pdf_path, output_folder)
    
    # Process images and get results
    results = process_images(output_folder)
    
    # Save results to JSON
    save_results_to_json(results, output_json_path)
    
    print(f"Results saved to {output_json_path}")
'''