import pandas as pd
import json
import os

def process_json_file(file_path):
    if not os.path.exists(file_path):
        print(f"Error: File not found at {file_path}")
        return pd.DataFrame()
    
    with open(file_path, 'r') as f:
        json_data = json.load(f)

    print("JSON Data Structure:", json_data)

    # Extract results directly from JSON
    results = json_data.get("results", [])

    if not results:
        print("No results found in JSON.")
        return pd.DataFrame()

    # Convert to DataFrame
    df_final = pd.DataFrame(results)

    # Ensure all required columns are present
    required_columns = ['Stu_ID', 'Subject_Name', 'Credit', 'Full_Marks', 'Obtained_Marks', 
                        'Subject_Letter_Grade', 'CGPA', 'Marks_or_Grade', 'Number_of_Fails']
    
    for col in required_columns:
        if col not in df_final.columns:
            df_final[col] = None  # Add missing columns with default value

    print("Processed DataFrame:")
    print(df_final.head())
    return df_final