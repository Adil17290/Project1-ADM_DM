import pickle
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import warnings
import re

warnings.filterwarnings("ignore")

def feature_engineering(df):
    """
    Perform feature engineering on the input DataFrame related to students' academic performance.

    Parameters:
    - df (pd.DataFrame): Input DataFrame containing academic data.

    Returns:
    - pd.DataFrame: DataFrame with additional features related to mathematics, programming, and overall performance.
    """
    try:
        # Columns to retain
        columns_to_select = ['Stu_ID', 'Subject_Name', 'Credit', 'Full_Marks', 'Obtained_Marks', 'Subject_Letter_Grade',
                             'CGPA', 'Marks_or_Grade']
        new_df = df[columns_to_select].copy()

        # Debugging: Print unique Subject_Name values
        print("Subject Names in DataFrame:")
        print(new_df['Subject_Name'].unique())

        # Ensure Subject_Name is a string
        new_df['Subject_Name'] = new_df['Subject_Name'].astype(str)

        # Regex pattern for math courses
        math_keywords_pattern = re.compile(
            r'\b(math|mathematics|calculus|linear algebra|probability|statistics|differential|discrete math|numerical analysis|maths|mathematical)\b',
            re.IGNORECASE,
        )

        # Detect math courses
        math_courses_df = new_df[new_df['Subject_Name'].str.contains(math_keywords_pattern, na=False)]
        print("Detected Math Courses:")
        print(math_courses_df[['Stu_ID', 'Subject_Name']])

        # Handle duplicates carefully
        math_courses_df = math_courses_df.drop_duplicates(subset=['Stu_ID', 'Subject_Name'], keep='first')
        math_courses_df[['Credit', 'Obtained_Marks', 'Full_Marks']] = math_courses_df[
            ['Credit', 'Obtained_Marks', 'Full_Marks']
        ].apply(pd.to_numeric, errors='coerce')

        if math_courses_df.empty:
            print("No math courses found!")
            df['Math_Weighted_Average'] = 0
            df['num_math_courses'] = 0
        else:
            # Calculate weighted averages for math courses
            weighted_averages = calculate_weighted_average(math_courses_df)
            df['Math_Weighted_Average'] = df['Stu_ID'].map(weighted_averages)
            df['num_math_courses'] = df['Stu_ID'].map(math_courses_df.groupby('Stu_ID').size())

        # Regex pattern for programming courses
        programming_keywords_pattern = re.compile(
            r'\b(java|python|c\+\+|data structures|computer science|programming|software engineering)\b', re.IGNORECASE
        )
        programming_courses_df = new_df[new_df['Subject_Name'].str.contains(programming_keywords_pattern, na=False)]
        print("Detected Programming Courses:")
        print(programming_courses_df[['Stu_ID', 'Subject_Name']])

        programming_courses_df = programming_courses_df.drop_duplicates(subset=['Stu_ID', 'Subject_Name'], keep='first')
        programming_courses_df[['Credit', 'Obtained_Marks', 'Full_Marks']] = programming_courses_df[
            ['Credit', 'Obtained_Marks', 'Full_Marks']
        ].apply(pd.to_numeric, errors='coerce')

        if programming_courses_df.empty:
            print("No programming courses found!")
            df['Programming_Weighted_Average'] = 0
            df['num_programming_courses'] = 0
        else:
            # Calculate weighted averages for programming courses
            weighted_averages_programming = calculate_weighted_average(programming_courses_df)
            df['Programming_Weighted_Average'] = df['Stu_ID'].map(weighted_averages_programming)
            df['num_programming_courses'] = df['Stu_ID'].map(programming_courses_df.groupby('Stu_ID').size())

        # Overall weighted average
        weighted_averages_all = calculate_weighted_average(new_df)
        df['Course_Weighted_Average'] = df['Stu_ID'].map(weighted_averages_all)

        # Number of Fails
        df['Number_of_Fails'] = df.groupby('Stu_ID')['Obtained_Marks'].apply(lambda x: (x < 40).sum())

    except Exception as e:
        print(f"Feature Engineering Error: {e}")
        df['Math_Weighted_Average'] = 0
        df['num_math_courses'] = 0
        df['Programming_Weighted_Average'] = 0
        df['num_programming_courses'] = 0
        df['Course_Weighted_Average'] = 0
        df['Number_of_Fails'] = 0

    return df


def calculate_weighted_average(df):
    """
    Calculate the weighted average for each student based on the input DataFrame.

    Parameters:
    - df (pd.DataFrame): Input DataFrame containing academic data.

    Returns:
    - dict: Dictionary mapping student IDs to their corresponding weighted averages.
    """
    grouped_courses = df.groupby('Stu_ID')
    weighted_averages = {
        student_id: round((courses['Credit'] * courses['Obtained_Marks']).sum() / courses['Credit'].sum(), 2)
        for student_id, courses in grouped_courses if courses['Credit'].sum() > 0
    }
    return weighted_averages


def predict(location_of_file):
    """
    Load the model and predict GPA based on student data.

    Parameters:
    - location_of_file (str): Path to the student's data file.

    Returns:
    - tuple: Predicted GPA and other academic features.
    """
    local_file_name = r"C:/Users/chara/Downloads/ADM-UI/GPA_model_DS.pkl"
    with open(local_file_name, 'rb') as file:
        loaded_model = pickle.load(file)

    df = pd.read_excel(location_of_file)
    df_new = feature_engineering(df)

    # Assign dummy values for encoding
    df_new['Degree_name'] = 10
    df_new['University'] = 2
    df_final = df_new[
        [
            'Math_Weighted_Average',
            'num_math_courses',
            'num_programming_courses',
            'Programming_Weighted_Average',
            'Course_Weighted_Average',
            'Degree_name',
            'University',
            'Number_of_Fails',
        ]
    ].drop_duplicates()

    # Apply Label Encoding if necessary
    for column in df_final.select_dtypes(include='object').columns:
        df_final[column] = LabelEncoder().fit_transform(df_final[column])

    df_final.fillna(0, inplace=True)
    if df_final.empty:
        print("The DataFrame is empty. No data available for prediction.")
        return None, None, None, None, None, None, None

    # Prediction
    gpa = "%.2f" % loaded_model.predict(df_final)[0]
    math_average = df_new['Math_Weighted_Average'].iloc[0]
    number_of_math_courses = df_new['num_math_courses'].iloc[0]
    programming_average = df_new['Programming_Weighted_Average'].iloc[0]
    number_of_programming_courses = df_new['num_programming_courses'].iloc[0]
    number_of_fails = df_new['Number_of_Fails'].iloc[0]
    course_weighted_average = df_new['Course_Weighted_Average'].iloc[0]

    return gpa, math_average, number_of_math_courses, programming_average, number_of_programming_courses, number_of_fails, course_weighted_average