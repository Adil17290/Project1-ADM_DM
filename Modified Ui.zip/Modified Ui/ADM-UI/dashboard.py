import tkinter as tk
from tkinter import scrolledtext, ttk
from PIL import Image, ImageTk
from ttkthemes import ThemedStyle
from on_premise import OnPremise
from style import Styles
from jsontodf import process_json_file
import os

# Set the working directory
os.chdir(r"C:/Users/chara/Downloads/ADM-UI")

premise = None

# Define the function to process JSON and display results
def extract_and_display_data():
    try:
        # Process the JSON file and create a DataFrame
        df_processed = process_json_file("C:/Users/chara/Downloads/ADM-UI/full_formatted_results_with_marks.json")
        
        if df_processed.empty:
            print("No data extracted from JSON.")
        else:
            # Display data in the console
            print("Extracted Data:")
            print(df_processed)
            
            # Alternatively, display the DataFrame in a new window or in the GUI
            display_window = tk.Toplevel(app)
            display_window.title("Extracted Data")

            # Text widget to display data
            text_area = scrolledtext.ScrolledText(display_window, width=100, height=20)
            text_area.pack(padx=10, pady=10)

            # Insert DataFrame content as text
            text_area.insert(tk.END, df_processed.to_string(index=False))

            # Keep the window open without affecting the main dashboard
            text_area.config(state=tk.DISABLED)

            # Add a button to close the display window
            close_button = ttk.Button(display_window, text="Close", style="TButton", cursor="hand2", command=display_window.destroy)
            close_button.pack(pady=10)

    except Exception as e:
        print(f"An error occurred while processing the JSON file: {e}")

# Function definitions for other GUI elements
def show_home():
    global premise
    if premise is not None:
        premise.mainFrame.destroy()
        premise = None

def show_about():
    show_content("Admissions Project.")

def show_how_to_use():
    universities = """
    List of Universities for Data Science Program: 
    JAWAHARLAL NEHRU TECHNOLOGICAL UNIVERSITY HYDERABAD
    JAWAHARLAL NEHRU TECHNOLOGICAL UNIVERSITY KAKINADA
    GITAM
    Lovely Professional University
    ACHARYA NAGARJUNA UNIVERSITY
    SATYABAMA INSTITUTE OF SCIENCE & TECHNOLOGY
    JNTUA
    GURU NANAK INSTITUTIONS TECHNICAL CAMPUS
    KATHMANDU UNIVERSITY
    University of Mumbai
    """
    show_content(universities)

def show_team():
    show_content("TEAMS")

def show_content(content_text, title="Content"):
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    content_window = tk.Toplevel(root)
    content_window.title(title)
    content_window.geometry(f"{int(screen_width*0.8)}x{int(screen_height*0.8)}")
    content_label = ttk.Label(content_window, text=content_text, font=("Arial", 16), wraplength=int(screen_width*0.7))
    content_label.pack(padx=20, pady=20)
    back_button = ttk.Button(content_window, text="Back", style="TButton", cursor="hand2", command=content_window.destroy)
    back_button.pack(side="bottom", padx=20, pady=10)

def selectMode(mode):
    if mode.get() == "Remote":
        pass
    else:
        premise = OnPremise(app)

app = tk.Tk()
app.title("Admissions Portal")
screen_width = app.winfo_screenwidth()
screen_height = app.winfo_screenheight()
app.geometry(f"{screen_width}x{screen_height}")

style = ThemedStyle(app)
style.set_theme("arc")

# Background image path
bg_image_path = "C:/Users/chara/Downloads/GUI/ADM-UI/images/university-new-haven_hero.jpeg"

# Check if background image exists
if os.path.exists(bg_image_path):
    bg_image = Image.open(bg_image_path)
    bg_image = bg_image.resize((screen_width, screen_height))
    bg_photo = ImageTk.PhotoImage(bg_image)
    background_label = tk.Label(app, image=bg_photo)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    background_label.lower()
else:
    print(f"Background image not found at {bg_image_path}. Please check the path or add the image.")
    background_label = tk.Label(app)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    background_label.lower()

# Nav Bar
nav_frame = tk.Frame(app, bg="#003e65", padx=20, pady=0, bd=1, relief="raised")
nav_frame.pack(side="left", fill="y")

nav_title = tk.Label(nav_frame, text="ADM-MENU", bg="#003e65", fg="white", font=("Arial", 20, "bold"))
nav_title.pack(pady=20)

nav_items = [
    ("HOME", show_home),
    ("ABOUT PROJECT", show_about),
    ("HOW TO USE", show_how_to_use),
    ("TEAM", show_team),
    ("Add student profiles", extract_and_display_data),  # Link to data extraction function
    ("Train model", None),
    ("About", None),
    ("Settings", None),
]

for item_text, command in nav_items:
    item_button = ttk.Button(nav_frame, text=item_text, style="TButton", cursor="hand2", command=command)
    item_button.pack(fill="x", padx=10, pady=5)

# KPIs
kpi_frame = tk.Frame(app, bg="#ffffff", bd=1, relief="raised")
kpi_frame.place(relx=0.95, rely=0.1, anchor="ne")

def create_kpi(parent, text, value):
    frame = tk.Frame(parent, bg="#0077b6", padx=10, pady=5, borderwidth=2, relief="solid")
    frame.pack(side="left", padx=10)
    title_label = tk.Label(frame, text=text, font=("Arial", 18, "bold"), fg="white", padx=5, pady=2, bg="#0077b6")
    title_label.pack(side="top", fill="x")
    value_frame = tk.Frame(frame)
    value_frame.pack(side="bottom", fill="x", padx=5, pady=2)
    value_label = tk.Label(value_frame, text=value, font=("Arial", 16), fg="black", padx=5, pady=2)
    value_label.pack()

kpi1_text = "Total applicants"
kpi1_value = "220"
create_kpi(kpi_frame, kpi1_text, kpi1_value)

kpi2_text = "Total Number of Transcripts"
kpi2_value = "220"
create_kpi(kpi_frame, kpi2_text, kpi2_value)

kpi3_text = "Predicted Average GPA"
kpi3_value = "3.42"
create_kpi(kpi_frame, kpi3_text, kpi3_value)

kpi4_text = "Model Accuracy"
kpi4_value = "71%"
create_kpi(kpi_frame, kpi4_text, kpi4_value)

# Radio button for mode of operation
radio_var = tk.StringVar()
radio_frame = tk.Frame(background_label, bg="#ffffff", borderwidth=2, relief="solid")
radio_frame.place(relx=0.55, rely=0.40, anchor="center")

radio_label = tk.Label(radio_frame, text="Mode of Operation", font=("Arial", 16), bg="#ffffff", fg="black")
radio_label.grid(row=0, column=0, padx=10, pady=10)

radio_option1 = tk.Radiobutton(radio_frame, text="On Premise", variable=radio_var, value="On Premise", font=("Arial", 14), bg="#ffffff", fg="black", activebackground="#ffffff", activeforeground="black")
radio_option1.grid(row=0, column=1, padx=10, pady=10)

radio_option2 = tk.Radiobutton(radio_frame, text="Remote", variable=radio_var, value="Remote", font=("Arial", 14), bg="#ffffff", fg="black", activebackground="#ffffff", activeforeground="black")
radio_option2.grid(row=0, column=2, padx=10, pady=10)

# Proceed button
style = ttk.Style()
style.theme_use("clam")
style.configure("TButton", padding=15, relief="flat", background="#023e8a", foreground="white", bordercolor="#023e8a", borderwidth=0, font=("Arial", 16))

proceed_button = ttk.Button(app, text="Proceed", style="TButton", cursor="hand2", width=20, command=lambda: selectMode(radio_var))
proceed_button.place(relx=0.55, rely=0.57, anchor="center")

app.mainloop()