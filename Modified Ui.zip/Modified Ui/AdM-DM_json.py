import pandas as pd
from tkinter import ttk
import tkinter as tk
from tkinter import simpledialog
from tkinter import filedialog
from tkinter import *
from PIL import Image, ImageTk
import PIL.Image
import csv
import psycopg2
from pdf2image import convert_from_path
import pytesseract
import cv2
import numpy as np
import re
import fitz  # PyMuPDF
import sys
from tkinter import scrolledtext
from openpyxl import Workbook
from openpyxl import load_workbook
from io import StringIO
import threading

sys.setrecursionlimit(20000)
import os
# from IPython.display import display, HTML
# sys.path.append('/Users/Sreenivas/Documents/GitHub/Admissions/app')

from typing import Optional
# from combined import process_and_display
from combined import extract_transcript
# from gpa_prediction_script import predict
from Final_Model_File_local import predict

from google.api_core.client_options import ClientOptions
from google.cloud import documentai

# os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "silent-grid-403505-f49743c0d64f.json"

# wait_label = 0

text_widget = None
predict_button_gpa = None
x_scrollbar_gpa = None
program_dropdown = None
upload_button = None
display_frame = None
predict_frame = None
program_label = None
program_frame = None
wait_label = None

def extract_and_display(file_path):
    global wait_label
    # wait_label.config(text="Extracting text from the file. Please wait ...")

    # Your existing code for text extraction
    df, details, generic_info, university, person_id = extract_transcript(file_path, wait_label)

    # Update the label after extraction is complete
    # wait_label.config(text="Extraction complete. You can now proceed.")


class EditableTable(tk.Frame):
    def __init__(self, parent, data):
        tk.Frame.__init__(self, parent)
        self.parent = parent
        self.data = data

        # Create Treeview widget
        self.tree = ttk.Treeview(self, columns=list(data.columns), show="headings")
        for col in data.columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor=tk.CENTER)

        # Insert data into Treeview
        for index, row in data.iterrows():
            self.tree.insert("", tk.END, values=list(row))

        # Bind double-click to edit
        self.tree.bind("<Double-1>", self.edit_cell)

        # Add Treeview to frame
        self.tree.pack(fill=tk.BOTH, expand=True)

    def edit_cell(self, event):
        region = self.tree.identify_region(event.x, event.y)

        if "cell" in region:
            item = self.tree.selection()[0]
            print('----')
            print(item)
            col = self.tree.identify_column(event.x).split("#")[-1]
            col = int(col)-1
            print(col)
            old_value = self.tree.item(item, "values")[col]
            print(old_value)
            new_value = simpledialog.askstring("Edit Cell", f"Edit cell value:", initialvalue=old_value)

            if new_value is not None:
                self.tree.set(item, col, new_value)

    def get_data_as_dataframe(self):
        # Retrieve data from Treeview and convert it to a DataFrame
        print(self.tree)
        print(type(self.tree))
        columns = self.tree["columns"]
        column_names = [self.tree.heading(col)["text"] for col in columns]
        data = []
        for item in self.tree.get_children(''):
            values = [self.tree.item(item, "values")[col] for col in range(len(column_names))]
            data.append(values)

        df = pd.DataFrame(data, columns=columns)
        return df

class GPAApp:
    global predict_button_gpa, text_widget
    def __init__(self, root):
        self.root = root
        self.root.title("GPA Prediction App")

        # Initially, show program selection
        self.show_program_selection()

    def show_program_selection(self):
        global program_dropdown, upload_button, program_label, program_frame
        # Create a new frame for program selection
        if hasattr(self, "program_frame"):
            self.program_frame.destroy()

        if hasattr(self, "display_frame"):
            self.display_frame.destroy()

        program_frame = tk.Frame(self.root)
        program_frame.pack()

        # Create label for program selection
        program_label = tk.Label(program_frame, text="Select the Program")
        program_label.pack(pady=10)

        # Create a style for the dropdown
        style = ttk.Style()
        style.configure('Custom.TCombobox', arrowcolor='black')

        # Create and set StringVar for the program dropdown
        self.selected_program = tk.StringVar()

        # Create a styled dropdown for program selection
        program_options = ["EOM", "Data Science"]
        program_dropdown = ttk.Combobox(program_frame, textvariable=self.selected_program, values=program_options, style='Custom.TCombobox')
        program_dropdown.pack(pady=10)

        # Create button to upload Excel file
        upload_button = tk.Button(program_frame, text="Upload", command=self.upload_excel)
        upload_button.pack(pady=20)

    def upload_excel(self):
        global predict_button_gpa, text_widget, x_scrollbar_gpa, display_frame, predict_frame
        # Open file dialog to select Excel file
        file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx;*.xls")])

        # Read Excel file using pandas
        try:
            self.df = pd.read_excel(file_path)
        except pd.errors.EmptyDataError:
            # Handle the case where the Excel file is empty
            tk.messagebox.showerror("Error", "Selected Excel file is empty.")
            return
        except pd.errors.ParserError:
            # Handle the case where the Excel file cannot be parsed
            tk.messagebox.showerror("Error", "Error parsing the selected Excel file.")
            return

        # Destroy the program frame
        program_frame.destroy()

        # Create a new frame for displaying Excel content
        display_frame = tk.Frame(self.root)
        display_frame.pack()

        # Create horizontal scrollbar
        x_scrollbar_gpa = tk.Scrollbar(display_frame, orient=tk.HORIZONTAL)
        x_scrollbar_gpa.pack(side=tk.BOTTOM, fill=tk.X)

        # Create text widget to display Excel content
        # self.text_widget = tk.Text(self.display_frame, wrap=tk.NONE, width=100, height=25, xscrollcommand=x_scrollbar.set)
        # self.text_widget.insert(tk.END, self.df.to_string(index=False))
        # self.text_widget.pack(pady=10)
        text_widget = tk.Text(display_frame, wrap=tk.NONE, width=100, height=25, xscrollcommand=x_scrollbar_gpa.set)
        text_widget.insert(tk.END, self.df.to_string(index=False))
        text_widget.pack(pady=10)


        # Connect horizontal scrollbar to text widget
        x_scrollbar.config(command=text_widget.xview)

        # Create a frame for "Predict" button
        predict_frame = tk.Frame(self.root)
        predict_frame.pack()

        # Create button to predict GPA
        predict_button_gpa = tk.Button(predict_frame, text="Predict", command=lambda: self.predict_gpa(file_path))
        predict_button_gpa.pack(pady=20)

    def predict_gpa(self, file_path):
        # Perform GPA prediction using the file_path or self.df
        # Replace the following line with your actual prediction logic
        selected_program = self.selected_program.get()

        # predicted_result = predict(selected_program, file_path)
        predicted_result = predict(file_path)
        # Display the predicted result
        # tk.messagebox.showinfo("GPA Prediction", f"The predicted result for the given details is: {predicted_result}")
            # Display the predicted result
        # predict_wait_label = 

        predicted_label = tk.Label(display_frame, text=f"Predicted GPA: {predicted_result}", font=("Times New Roman", 15), fg="green")
        predicted_label.pack(pady=10)


class PDFViewer(tk.Frame):
    def __init__(self, parent, pdf_path):
        tk.Frame.__init__(self, parent)
        self.parent = parent
        self.pdf_path = pdf_path
        self.current_page = 0

        self.pdf_document = fitz.open(pdf_path)
        self.total_pages = len(self.pdf_document)

        self.pdf_label = tk.Label(self)
        self.pdf_label.pack(side="top")

        # Add "Previous" and "Next" buttons
        prev_button = tk.Button(self, text="Previous", command=self.show_prev_page)
        prev_button.pack(side="left", padx=5)
        next_button = tk.Button(self, text="Next", command=self.show_next_page)
        next_button.pack(side="left", padx=5)

        self.show_page()

    def show_page(self):
        pdf_page = self.pdf_document.load_page(self.current_page)
        img = pdf_page.get_pixmap()
        img = Image.frombytes("RGB", [img.width, img.height], img.samples)
        img = ImageTk.PhotoImage(img)
        self.pdf_label.config(image=img, width=750, height=750)
        self.pdf_label.image = img

    def show_prev_page(self):
        if self.current_page > 0:
            self.current_page -= 1
            self.show_page()

    def show_next_page(self):
        if self.current_page < self.total_pages - 1:
            self.current_page += 1
            self.show_page()

def open_file():
    file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif *.bmp *.pdf")])

    if file_path.endswith('.pdf'):
        img_label.pack_forget()
        pdf_document = fitz.open(file_path)
        pdf_page = pdf_document.load_page(0)
        img = pdf_page.get_pixmap()
        img = Image.frombytes("RGB", [img.width, img.height], img.samples)
        img = ImageTk.PhotoImage(img)
        img_pdf.config(image=img, width=400, height=400)
        img_pdf.image = img
        img_pdf.pack(side="top")
    else:
        img_pdf.pack_forget()
        img_label.pack_forget()
        img = Image.open(file_path)
        img = ImageTk.PhotoImage(img)
        img_label.config(image=img, width=400, height=400)
        img_label.image = img
        img_label.pack(side="top")

    submit_button.pack()

def on_radiobutton_select(event):
    selected_option = radio_var.get()
    img_label.pack_forget()

    if selected_option == "Remote":
        upload_label.pack_forget()
        dropdown.pack_forget()
        img_label.pack_forget()
        img_pdf.pack_forget()
        submit_button.pack_forget()
        upload_button.pack_forget()
        data_ingest_button.pack_forget()
        predict_button.pack_forget()
        display_text.pack_forget()
        label1.pack_forget()
        entry_label.pack(side= "top", padx= 20, pady= 20)
        entry.pack(side = "top")
        entry_button.pack(side= "top", padx= 20, pady= 20)


    elif selected_option == "On-Premise":
        if text_widget is not None:
            text_widget.pack_forget()
        if predict_button_gpa is not None:
            predict_button_gpa.pack_forget()
        if x_scrollbar_gpa is not None:
            x_scrollbar_gpa.pack_forget()
        if program_dropdown is not None:
            program_dropdown.pack_forget()
        if upload_button is not None:
            upload_button.pack_forget()
        if display_frame is not None:
            display_frame.destroy()
        if predict_frame is not None:
            predict_frame.destroy()
        if program_label is not None:
            program_label.pack_forget()
        if program_frame is not None:
            program_frame.destroy()
        if wait_label is not None:
            wait_label.pack_forget()

        upload_label.pack_forget()
        entry_label.pack_forget()
        entry.pack_forget()
        entry_button.pack_forget()
        upload_button.pack_forget()
        img_label.pack_forget()
        img_pdf.pack_forget()
        submit_button.pack_forget()
        dropdown.pack_forget()
        data_ingest_button.pack_forget()
        predict_button.pack_forget()
        display_text.pack_forget()
        label1.pack_forget()
        label1.pack(side= "top", padx= 20, pady= 20)
        data_ingest_button.pack(side = 'top', padx = 10, pady= 10)
        predict_button.pack(side = 'top', padx = 10, pady= 10)

changes_label = None

def open_editor(df, file_path):

    # global display_text
    global changes_label
    edit_button.pack_forget()
    display_text.pack_forget()
    csv_editor_window = tk.Toplevel(window)
    csv_editor_window.title("PDF and CSV Editor")

    # Create a PanedWindow to separate the left and right panes
    paned_window = ttk.PanedWindow(csv_editor_window, orient=tk.HORIZONTAL)
    paned_window.pack(expand=True, fill=tk.BOTH)

    # Create a left pane for displaying PDF
    left_pane = PDFViewer(paned_window, pdf_path=file_path)
    paned_window.add(left_pane, weight=1)

    # Create a right pane for text display
    right_pane = tk.Frame(paned_window)
    paned_window.add(right_pane, weight=1)

    txt_file_path = r"C:\Users\Sreenivas\Desktop\Desktop_Files\MS Docs\New Haven\Courses\Campus_Employment\RA\Github_Local\Admissions_Local\Data\mvp_demo\demo_json.txt"
    # Display contents of the text file in a Text widget
    with open(txt_file_path, "r") as f:
        text_contents = f.read()
    
    text_display = tk.Text(right_pane)
    text_display.insert(tk.END, text_contents)
    text_display.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    # Changes label
    changes_label = tk.Label(right_pane, text="", width=15)
    changes_label.pack(side=tk.TOP, pady=5)

    # Export button
    # export_button = ttk.Button(right_pane, text="Export to Excel", command=lambda: export_to_excel(csv_display))
    # export_button = ttk.Button(right_pane, text="Export to Excel", command=lambda: export_to_excel(csv_display))
    
    # export_button.pack(side=tk.TOP, pady=30)

    # instance = GPAApp()
    excel_path = r"C:/Users/chara/Downloads/ADM-UI/full_formatted_results_with_marks.xlsx"
    predict_button_new = ttk.Button(right_pane, text="Predict", command=lambda: predict_gpa_new(excel_path))
    predict_button_new.pack(side=tk.TOP, pady=30)

    def predict_gpa_new(file_path):
        # Perform GPA prediction using the file_path or self.df
        # Replace the following line with your actual prediction logic
        # selected_program = self.selected_program.get()

        # predicted_result = predict(selected_program, file_path)
        predicted_result = predict(file_path)
        # Display the predicted result
        # tk.messagebox.showinfo("GPA Prediction", f"The predicted result for the given details is: {predicted_result}")
            # Display the predicted result
        # predict_wait_label = 

        predicted_label = tk.Label(right_pane, text=f"Predicted GPA: {predicted_result}", font=("Times New Roman", 15), fg="green")
        predicted_label.pack(side=tk.TOP,pady=25)
        window.after(5000, lambda: predicted_label.pack_forget())

import pandas as pd
from openpyxl import Workbook

def export_to_excel(display_widget, generic_info, university, person_id):

    result_df = display_widget.get_data_as_dataframe()
    wb = Workbook()
    ws = wb.active

    ws['A1'] = 'Name'
    ws['B1'] = generic_info['Name']
    ws['A2'] = 'University'
    ws['B2'] = generic_info['University']

    ws['A3'] = 'Course'
    ws['B3'] = generic_info['Course']

    ws['A4'] = 'CGPA'
    ws['B4'] = ''

    ws['A5'] = 'PERCENTAGE'
    ws['B5'] = ''

    ws['A6'] = 'Marks/Grade System(M/G)'
    ws['B6'] = 'M'
    ws['C6'] = 'Grade Point Available(Y/N)'
    ws['D6'] = ''

    # Leave the 7th row empty
    for col in range(1, 5):
        ws.cell(row=7, column=col, value='')

    # Column names starting from row 8
    column_names = ['Semester', 'Subject', 'Credit', 'Grade', 'Grade Point', 'Total Marks', 'Marks Obtained']

    # Write column names to row 8
    for col_num, col_name in enumerate(column_names, start=1):
        ws.cell(row=8, column=col_num, value=col_name)

    result_df = result_df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    # Iterate through the original DataFrame starting from the 9th row
    for index, row in result_df.iterrows():
        if university=='Osmania':
            semester = row['S_No']
            subject = row['Subject']

            try:
                total_marks = int(row['Examination_Max_Marks']) + int(row['Sessional_Max_Marks'])
            except ValueError:
                # Set total_marks to None if an error occurs
                total_marks = None

            try:
                marks_obtained = int(row['Examination_Marks_Secured']) + int(row['Sessional_Marks_Secured'])
            except ValueError:
                # Set marks_obtained to None if an error occurs
                marks_obtained = None

            # Write the details starting from the 9th row
            ws.append([semester, subject, '', '', '', total_marks, marks_obtained])

        else:
            semester = row['S. No.']
            subject = row['Course Title']
            credit = row['Credit Obtained']
            grade = row['Grade Secured']
            grade_point = row['Grade Point']
            # Write the details starting from the 9th row
            ws.append([semester, subject,credit,grade,grade_point, '', ''])

    export_file_path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])
    wb.save(export_file_path)

    try:
        changes_label.config(text="Export successful", fg="green")
        window.after(10000, lambda: changes_label.destroy())
    except Exception as e:
        changes_label.config(text=f"Error: {str(e)}", fg="red")

# Define the 'Edit' function
def Edit(df, selected_column, new_value_entry, csv_display):
    try:
        selected_id = 1  # You need to replace this with the actual selected ID
        df.loc[df["Course Code"] == int(selected_id), selected_column] = str(new_value_entry.get())
        csv_display.delete(1.0, tk.END)
        csv_display.insert(tk.END, df.to_string(index=False))
    except ValueError:
        print("Invalid input. Please enter a valid value.")

def Predictions():
    data_ingest_button.pack_forget()
    label1.pack_forget()
    predict_button.pack_forget()

    # if edit_button is not None:
    #     edit_button.destroy()

    GPAApp(window)

# edit_button = None

def Data_Ingestion():
    global edit_button, wait_label
    upload_label.pack_forget()
    dropdown.pack_forget()
    img_label.pack_forget()
    img_pdf.pack_forget()
    submit_button.pack_forget()
    upload_button.pack_forget()
    predict_button.pack_forget()
    label1.pack_forget()
    display_text.pack_forget()
    predict_button.pack_forget()
    wait_label.pack()
    
    # edit_button.pack_forget()
    
    file_path = filedialog.askopenfilename(filetypes=[("PDF Files", "*.pdf")])
    
    # if edit_button is not None:
    #     edit_button.destroy()

    if file_path.endswith(".pdf"):

        # global display_text
        # wait_label = tk.Label(window, text="Extracting text from the file. Please wait ...")
        # wait_label.pack()

        # Run the extraction process in a separate thread
        # extraction_thread = threading.Thread(target=extract_and_display, args=(file_path,))
        # extraction_thread.start()
        # # Schedule the label update after a short delay
        # window.after(100, label.config(text="Extracting text from the file. Please wait ..."), wait_label)  
    

        # wait_label.config(text="Extracting text from the file. Please wait ...")
    # 
        # df, details = process_and_display(file_path)
        #commented
        # df, details, generic_info, university, person_id = extract_transcript(file_path, wait_label)
    
        # wait_label.config(text="Extraction complete. You can now proceed.")
        wait_label.pack_forget()

        record = 1
        # print(type(df))
        display_text.pack(padx=10, pady=10)
        x_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        y_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        display_text.configure(xscrollcommand=x_scrollbar.set, yscrollcommand=y_scrollbar.set)
        df= pd.read_excel(r"C:/Users/chara/Downloads/ADM-UI/full_formatted_results_with_marks.xlsx")
        display_dataframe(display_text, df)
        # label_text = "All records OK"
        # inserted_label = tk.Label(window, text = label_text)
        # inserted_label.pack()
        # window.after(5000, lambda: inserted_label.pack_forget())
        # display_text.pack()
        # display_data(df.to_string(index=False))

        edit_button = tk.Button(window, text="Edit", command = lambda: open_editor(df, file_path))
        edit_button.pack()

    else:
        result_label = tk.Label(window, text="Other file formats are not supported yet")
        result_label.pack()
        window.after(5000, lambda: result_label.pack_forget())

def on_dropdown_select(event):
    selected_option = selected_option.get()
    print(selected_option)
    if selected_option == "EOM":
        # proceed_button.pack_forget()
        upload_button.pack()
        img_label.pack()
        # submit_button.pack()
    elif selected_option == "Data Science":
        # proceed_button.pack_forget()
        upload_button.pack()
        img_label.pack()
        # submit_button.pack()
    else:
        proceed_button.pack_forget()
        upload_button.pack_forget()
        submit_button.pack_forget()

def upload_file():
    # global result_label
    upload_label = tk.Label(window, text="Please upload the files here")
    upload_label.pack()
    # window.after(4000, lambda: result_label.pack_forget())


def submit_file():
    # global result_label
    result_label = tk.Label(window, text="You can check the result once the model is integrated with the application")
    result_label.pack()
    window.after(4000, lambda: result_label.pack_forget())

def url_check():
    global input
    text = entry.get()
    # label.config(text=f"The connection is not configured yet.")
    url_label = tk.Label(text= f"The connection is not configured yet.")
    url_label.pack()
    window.after(4000, lambda: url_label.pack_forget())


def display_data(data):
    display_text.delete(1.0, tk.END)  # Clear any previous data in the Text widget
    display_text.insert(tk.END, data)

def display_dataframe(text_widget, dataframe):
    text_widget.delete("1.0", tk.END)  # Clear the existing content

    # Convert the DataFrame to a string
    dataframe_str = str(dataframe)

    # Insert the DataFrame string into the Text widget
    text_widget.insert(tk.END, dataframe_str)

def Export_to_excel():
    return 0 


# Start the GUI main loop
window = tk.Tk()
window.title("Admissions Project")
window.geometry("800x600")

img_pdf = tk.Label(window)
# Create a label to display the image/PDF
img_label = tk.Label(window)
# Get screen width and height
upload_label = tk.Label(window, text="Please upload the files here")

radio_var = tk.StringVar()
option1_radio = tk.Radiobutton(window, text="Remote", variable=radio_var, value="Remote")
option2_radio = tk.Radiobutton(window, text="On_Premise", variable=radio_var, value="On-Premise")

label = tk.Label(window, text="Please select your mode of operation:")
label.pack(side="top", anchor="w", padx=20, pady=10)
option1_radio.pack(side="top", anchor="w", padx=20, pady=10)
option2_radio.pack(side="top", anchor="w", padx=20)

label1 = tk.Label(window, text="Select an option:")
# display_text = tk.Text(window, height=15, width=85)

display_text = scrolledtext.ScrolledText(window, height=15, width=150)
# display_text.pack(padx=10, pady=10)

x_scrollbar = tk.Scrollbar(window, orient=tk.HORIZONTAL, command=display_text.xview)
y_scrollbar = tk.Scrollbar(window, orient=tk.VERTICAL, command=display_text.yview)



entry_label = tk.Label(window, text="Please enter the URL below:")
entry = tk.Entry(window)
entry_button = tk.Button(window, text="Submit URL", command=url_check)

upload_button = tk.Button(window, text="Upload File", command=open_file)
submit_button = tk.Button(window, text="Submit", command=submit_file)
proceed_button = tk.Button(window, text="Proceed", command=lambda: on_radiobutton_select(radio_var))
data_ingest_button = tk.Button(window, text="Transcript Data Extraction", command=Data_Ingestion)
predict_button = tk.Button(window, text="Predictions", command=Predictions)
export_button = tk.Button(window, text="Export to Excel", command=Export_to_excel)
predict_button_new = ttk.Button(window, text="Predict", command=predict)
wait_label = tk.Label(window, text="Extracting text from the file. Please wait ...")

proceed_button.pack(side="top", padx=20, pady=20)
options = ["EOM", "Data Science"]
selected_option = tk.StringVar()
dropdown = ttk.Combobox(window, textvariable=selected_option, values=options)
dropdown.bind("<<ComboboxSelected>>", on_dropdown_select)

window.mainloop()
