from pdf2image import convert_from_path
import os
import json
import glob
from utils import TranscriptOCR
import shutil

# Initialize the TranscriptOCR object
transcriptocr = TranscriptOCR()

def clear_output_folder(output_folder):
    """
    Clears all files in the output folder.
    """
    if not os.path.exists(output_folder):
        print(f"Creating output folder: {output_folder}")
        os.makedirs(output_folder)
        return

    # Delete all files in the folder
    for filename in os.listdir(output_folder):
        file_path = os.path.join(output_folder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
                print(f"Deleted file: {file_path}")
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
                print(f"Deleted folder: {file_path}")
        except Exception as e:
            print(f"Failed to delete {file_path}. Reason: {e}")

def pdf_to_images(pdf_path, output_folder):
    """
    Converts a PDF to images and saves them in the specified output folder.
    """
    # Check if the PDF file exists
    if not os.path.exists(pdf_path):
        print(f"Error: PDF file not found at {pdf_path}")
        return

    print(f"\nLoading PDF: {pdf_path}")

    # Ensure the output folder exists
    os.makedirs(output_folder, exist_ok=True)

    try:
        # Convert PDF to images
        images = convert_from_path(pdf_path)
        print("\nConverting PDF to images...\n")
        for i, image in enumerate(images):
            image_path = os.path.join(output_folder, f"page_{i+1}.jpg")
            image.save(image_path, 'JPEG')
            print(f"Image saved: {image_path}")
    except Exception as e:
        print(f"Error during PDF to image conversion: {e}")

def process_images(image_folder):
    """
    Processes images in a folder using TranscriptOCR.
    """
    # Get a list of all image files in the directory
    image_files = glob.glob(f"{image_folder}/*.jpg") + glob.glob(f"{image_folder}/*.png")

    # Initialize an empty list to store the results
    results = []

    # Loop through each image file and process it
    for image_file in image_files:
        try:
            result = transcriptocr.extract_json(image_file)
            results.append(result)
        except Exception as e:
            print(f"Failed to process {image_file}: {e}")

    return results

def save_results_to_json(results, output_path):
    """
    Saves the OCR results to a JSON file.
    """
    # Combine all the results into a single JSON object
    combined_result = {"results": results}
    combined_json = json.dumps(combined_result, indent=4)

    # Write the combined JSON object to a file
    with open(output_path, "w") as f:
        f.write(combined_json)

# Main execution
if __name__ == "__main__":
    # Dynamic file and folder selection
    from tkinter import filedialog
    from tkinter import Tk

    # Hide the main Tkinter window
    Tk().withdraw()

    # Ask the user to select a PDF file
    pdf_path = filedialog.askopenfilename(title="Select PDF File", filetypes=[("PDF Files", "*.pdf")])
    
    if pdf_path:
        output_folder = r"C:/Users/chara/Downloads/Modified Ui/Image_Folder"
        output_json_path = r"C:/Users/chara/Downloads/Modified Ui/full_formatted_results_with_marks.json"

        # Clear the output folder before saving new images
        clear_output_folder(output_folder)

        # Convert PDF to images
        pdf_to_images(pdf_path, output_folder)

        # Process images and get results
        results = process_images(output_folder)

        # Save results to JSON
        save_results_to_json(results, output_json_path)

        print(f"Results saved to {output_json_path}")
        print(f"Images saved in folder: {output_folder}")
    else:
        print("No file selected. Exiting.")